var g_db_data = {"3":1,"2":1,"1":1};
processScopesDbFile(g_db_data);