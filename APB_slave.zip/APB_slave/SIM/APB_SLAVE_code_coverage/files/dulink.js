var g_data = {"2":["work.APB_SLAVE_design",90.16,1],"1":["work.APB_SLAVE_tb",71.86,1]};
processDuLinks(g_data);