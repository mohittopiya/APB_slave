var g_data = ["","../TB/APB_SLAVE_tb.v","../RTL/APB_SLAVE_design.v"];
processSrcNamesData(g_data);